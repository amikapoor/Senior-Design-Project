package org.camunda.bpm.listprocessing;

import org.camunda.bpm.application.ProcessApplication;
import org.camunda.bpm.application.impl.ServletProcessApplication;

@ProcessApplication("List Processing")
public class ListProcessingApplication extends ServletProcessApplication {
// empty implementation
}
