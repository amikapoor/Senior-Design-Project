package org.camunda.bpm.listprocessing;

public class ListCleansing {

}
